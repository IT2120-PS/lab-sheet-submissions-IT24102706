#Q1
setwd("C:\\Users\\IT24102706\\Desktop\\IT24102706")
branch_data<-read.csv("Exercise.txt",header = TRUE)
#Q2
str(branch_data)
summary(branch_data)
#Q3
boxplot(branch_data$Sales_X1, main="Boxplot of sales",outline=TRUE,outpch=1,horizontal=TRUE)

#Q4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5

get_outliers <- function(x){
  Q1 <- quantile(x)[2]
  Q3 <- quantile(x)[4]
  IQR_value <- Q3-Q1
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  print(paste("Lower bound = ",lower_bound))
  print(paste("Upper bound = ",upper_bound))
  print(paste("outliers: ", paste(x[x<lower_bound | x>upper_bound]),collapse="," ))
  
}

get_outliers(branch_data$Years_X3) 